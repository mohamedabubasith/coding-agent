
- [ ] Initialize backend directory
