
- [ ] Create project directory structure
