
## Execution Result
```
Command execution failed: Command 'cd app && uvicorn main:app --reload --host 0.0.0.0 --port 8000 & sleep 3 && curl -X GET http://localhost:8000/hello' timed out after 30 seconds
```

## Execution Result
```
Command: cd tests && python -m pytest test_main.py -v
Stdout:

Stderr:
/bin/sh: python: command not found

```
