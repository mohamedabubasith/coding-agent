from fastapi.testclient import TestClient
from your_app import app  # Replace 'your_app' with the actual module name where your FastAPI app is defined

def test_hello_endpoint():
    client = TestClient(app)
    response = client.get("/hello")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello World"}