
- [ ] Initialize project structure
