"""Context package for project understanding."""
