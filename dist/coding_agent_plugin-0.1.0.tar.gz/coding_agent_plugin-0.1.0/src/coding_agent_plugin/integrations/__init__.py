"""Integrations package for coding-agent-plugin."""
