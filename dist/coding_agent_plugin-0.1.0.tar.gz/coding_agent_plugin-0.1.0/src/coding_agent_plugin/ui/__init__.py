"""UI package for coding-agent-plugin."""
