def main():
    print("Hello from coding-agent-plugin!")


if __name__ == "__main__":
    main()
