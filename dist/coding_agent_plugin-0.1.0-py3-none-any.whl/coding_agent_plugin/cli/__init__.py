"""CLI package for coding-agent-plugin."""
